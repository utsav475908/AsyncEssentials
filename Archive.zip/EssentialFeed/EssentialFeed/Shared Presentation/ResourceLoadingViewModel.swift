//
//  Copyright © 2019 Essential Developer. All rights reserved.
//

public struct ResourceLoadingViewModel {
	public let isLoading: Bool
}
